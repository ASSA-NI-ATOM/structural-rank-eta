# analyze.py — η-π Correlation Analysis
# Author: S. V. Tabalevich  
# ORCID: https://orcid.org/0009-0007-4425-9443
# Analysis: Correlation between structural rank η(k) and prime distribution π(I_k)

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
import csv
import time

try:
    from scipy.stats import spearmanr, pearsonr
    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False
    print("⚠ scipy не установлен. Некоторые статистические тесты будут недоступны.")

def sieve_of_eratosthenes(limit):
    """Генерирует простые числа до limit методом решета."""
    if limit < 2:
        return []
    is_prime = [True] * (limit + 1)
    is_prime[0] = is_prime[1] = False
    for i in range(2, int(limit**0.5) + 1):
        if is_prime[i]:
            for j in range(i*i, limit + 1, i):
                is_prime[j] = False
    return [i for i, prime in enumerate(is_prime) if prime]

def compute_eta_k(k):
    """Вычисляет структурный ранг η(k) методом перебора (для малых k)."""
    # C(k) = 1 + (-k mod 4)
    C = 1 + ((-k) % 4)
    T_k = k - 2 + C
    
    if T_k % 4 != 3:
        return None  # T должно быть ≡ 3 (mod 4)
    
    # Ищем η как минимальный n такой, что T + (2n-1)² = y²
    for n in range(1, 1000):  # Ограничиваем поиск
        two_n_minus_1 = 2 * n - 1
        candidate = T_k + two_n_minus_1 * two_n_minus_1
        sqrt_candidate = int(candidate ** 0.5)
        if sqrt_candidate * sqrt_candidate == candidate:
            return n
    
    return None  # η не найден в заданном диапазоне

def compute_pi_interval(k, interval_type='standard'):
    """Вычисляет π(I_k) - количество простых в интервале I_k."""
    if interval_type == 'standard':
        # Стандартный интервал вокруг k
        start = max(2, k - int(k**0.5))
        end = k + int(k**0.5)
    elif interval_type == 'structural':
        # Интервал на основе структурного ранга
        C = 1 + ((-k) % 4)
        T_k = k - 2 + C
        start = max(2, int(T_k**0.5))
        end = T_k
    else:
        # Простой интервал [k/2, k]
        start = max(2, k // 2)
        end = k
    
    primes = sieve_of_eratosthenes(end)
    primes_in_interval = [p for p in primes if start <= p <= end]
    return len(primes_in_interval), start, end

def collect_eta_pi_data(k_start=1000, k_end=5000, output_file='results/eta_pi_data.csv'):
    """Собирает данные η(k) vs π(I_k)."""
    Path('results').mkdir(exist_ok=True)
    
    print(f"Сбор данных η-π корреляции для k ∈ [{k_start}, {k_end}]")
    print("=" * 60)
    
    data = []
    found_eta = 0
    processed = 0
    start_time = time.time()
    
    for k in range(k_start, k_end + 1):
        try:
            # Вычисляем η(k)
            eta_k = compute_eta_k(k)
            
            # Вычисляем π(I_k) для разных типов интервалов
            pi_standard, start_std, end_std = compute_pi_interval(k, 'standard')
            pi_structural, start_struct, end_struct = compute_pi_interval(k, 'structural')
            pi_simple, start_simple, end_simple = compute_pi_interval(k, 'simple')
            
            # Сохраняем данные
            row = {
                'k': k,
                'eta': eta_k if eta_k is not None else -1,
                'pi_standard': pi_standard,
                'interval_std_start': start_std,
                'interval_std_end': end_std,
                'pi_structural': pi_structural,
                'interval_struct_start': start_struct,
                'interval_struct_end': end_struct,
                'pi_simple': pi_simple,
                'interval_simple_start': start_simple,
                'interval_simple_end': end_simple
            }
            data.append(row)
            
            processed += 1
            if eta_k is not None:
                found_eta += 1
            
            # Прогресс
            if processed % 500 == 0:
                elapsed = time.time() - start_time
                rate = processed / elapsed
                eta_rate = found_eta / processed * 100
                print(f"k = {k}, обработано: {processed}, η найден: {found_eta} ({eta_rate:.1f}%), скорость: {rate:.1f}/сек")
                
        except Exception as e:
            print(f"❌ Ошибка для k = {k}: {e}")
            continue
    
    # Сохраняем в CSV
    if data:
        df = pd.DataFrame(data)
        df.to_csv(output_file, index=False)
        
        elapsed = time.time() - start_time
        print(f"\n✓ Данные сохранены в {output_file}")
        print(f"Обработано: {processed}, η найден: {found_eta}")
        print(f"Время: {elapsed:.1f} сек")
        
        return df
    else:
        print("❌ Нет данных для сохранения")
        return None

def analyze_eta_pi_correlation(df_file='results/eta_pi_data.csv'):
    """Анализирует корреляцию между η(k) и π(I_k)."""
    try:
        df = pd.read_csv(df_file)
        print(f"✓ Загружено {len(df)} записей из {df_file}")
    except FileNotFoundError:
        print(f"❌ Файл {df_file} не найден. Сначала соберите данные.")
        return None
    
    # Фильтруем валидные данные
    df_valid = df[df['eta'] > 0]
    
    if len(df_valid) == 0:
        print("❌ Нет валидных данных с найденными η")
        return None
    
    print(f"Валидных записей для анализа: {len(df_valid)}")
    
    # Анализируем корреляции для разных типов интервалов
    interval_types = ['standard', 'structural', 'simple']
    pi_columns = ['pi_standard', 'pi_structural', 'pi_simple']
    
    results = {}
    
    print("\n" + "="*60)
    print("КОРРЕЛЯЦИОННЫЙ АНАЛИЗ η(k) vs π(I_k)")
    print("="*60)
    
    for interval_type, pi_col in zip(interval_types, pi_columns):
        print(f"\n📊 Интервал: {interval_type}")
        
        eta_values = df_valid['eta'].values
        pi_values = df_valid[pi_col].values
        
        # Статистики
        print(f"η диапазон: [{eta_values.min()}, {eta_values.max()}]")
        print(f"π диапазон: [{pi_values.min()}, {pi_values.max()}]")
        print(f"Среднее η: {eta_values.mean():.2f}")
        print(f"Среднее π: {pi_values.mean():.2f}")
        
        # Корреляции
        correlations = {}
        
        # Пирсон
        try:
            pearson_corr = np.corrcoef(eta_values, pi_values)[0, 1]
            correlations['pearson'] = pearson_corr
            print(f"Корреляция Пирсона: {pearson_corr:.4f}")
        except:
            correlations['pearson'] = None
        
        # Спирмен (если доступен)
        if SCIPY_AVAILABLE:
            try:
                spearman_corr, spearman_p = spearmanr(eta_values, pi_values)
                correlations['spearman'] = spearman_corr
                correlations['spearman_p'] = spearman_p
                print(f"Корреляция Спирмена: {spearman_corr:.4f} (p = {spearman_p:.2e})")
            except:
                correlations['spearman'] = None
        
        results[interval_type] = correlations
        
        # Интерпретация
        primary_corr = correlations.get('spearman') or correlations.get('pearson')
        if primary_corr is not None:
            if primary_corr < -0.3:
                print("✅ Обратная корреляция обнаружена!")
                print("   Подтверждение: малое η → больше простых")
            elif primary_corr > 0.3:
                print("❌ Прямая корреляция (против ожидания)")
            else:
                print("⚠️ Слабая корреляция")
    
    return df_valid, results

def create_eta_pi_visualization(df_valid, output_dir='results'):
    """Создает визуализации η-π корреляций."""
    Path(output_dir).mkdir(exist_ok=True)
    
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    fig.suptitle('η(k) vs π(I_k) Correlation Analysis\nAuthor: S. V. Tabalevich', fontsize=14)
    
    interval_types = ['standard', 'structural', 'simple']
    pi_columns = ['pi_standard', 'pi_structural', 'pi_simple']
    colors = ['blue', 'green', 'red']
    
    # Scatter plots
    for i, (interval_type, pi_col, color) in enumerate(zip(interval_types, pi_columns, colors)):
        ax = axes[0, i]
        ax.scatter(df_valid['eta'], df_valid[pi_col], alpha=0.6, s=20, c=color)
        ax.set_xlabel('Структурный ранг η(k)')
        ax.set_ylabel(f'π(I_k) - {interval_type}')
        ax.set_title(f'{interval_type.capitalize()} interval')
        ax.grid(True, alpha=0.3)
        
        # Логарифмический масштаб если нужен
        if df_valid['eta'].max() > 100:
            ax.set_xscale('log')
    
    # Гистограммы и boxplots
    ax = axes[1, 0]
    ax.hist(df_valid['eta'], bins=50, alpha=0.7, color='orange', edgecolor='black')
    ax.set_xlabel('η(k)')
    ax.set_ylabel('Частота')
    ax.set_title('Распределение η(k)')
    ax.grid(True, alpha=0.3)
    
    ax = axes[1, 1]
    ax.hist(df_valid['pi_standard'], bins=30, alpha=0.7, color='purple', edgecolor='black')
    ax.set_xlabel('π(I_k)')
    ax.set_ylabel('Частота')
    ax.set_title('Распределение π(I_k)')
    ax.grid(True, alpha=0.3)
    
    # Корреляционная матрица
    ax = axes[1, 2]
    corr_data = df_valid[['eta'] + pi_columns].corr()
    im = ax.imshow(corr_data.values, cmap='RdBu_r', vmin=-1, vmax=1)
    ax.set_xticks(range(len(corr_data.columns)))
    ax.set_yticks(range(len(corr_data.columns)))
    ax.set_xticklabels(['η'] + [f'π_{t}' for t in interval_types], rotation=45)
    ax.set_yticklabels(['η'] + [f'π_{t}' for t in interval_types])
    ax.set_title('Correlation Matrix')
    
    # Добавляем числовые значения корреляций
    for i in range(len(corr_data.columns)):
        for j in range(len(corr_data.columns)):
            text = ax.text(j, i, f'{corr_data.iloc[i, j]:.2f}',
                         ha="center", va="center", color="black", fontweight='bold')
    
    plt.colorbar(im, ax=ax, shrink=0.6)
    plt.tight_layout()
    plt.savefig(f"{output_dir}/eta_pi_correlation.png", dpi=150, bbox_inches='tight')
    plt.show()
    
    print(f"✓ Визуализация сохранена в {output_dir}/eta_pi_correlation.png")

def main():
    """Основная функция η-π анализа."""
    print("Structural Rank η(k) vs Prime Distribution π(I_k) Analysis")
    print("Author: S. V. Tabalevich")
    print("========================================================")
    
    # Проверяем наличие данных
    data_file = 'results/eta_pi_data.csv'
    
    if not Path(data_file).exists():
        print(f"❌ Файл данных {data_file} не найден.")
        response = input("Собрать данные сейчас? (y/n): ").strip().lower()
        
        if response == 'y':
            print("Начинаем сбор данных...")
            df = collect_eta_pi_data(k_start=1000, k_end=3000)
            if df is None:
                return
        else:
            print("Сбор данных отменен.")
            return
    
    # Анализируем корреляции
    result = analyze_eta_pi_correlation(data_file)
    if result is None:
        return
    
    df_valid, correlations = result
    
    # Создаем визуализации
    create_eta_pi_visualization(df_valid)
    
    # Сохраняем отчет
    report_file = 'results/eta_pi_analysis_report.txt'
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write("η(k) vs π(I_k) Correlation Analysis Report\n")
        f.write("==========================================\n")
        f.write("Author: S. V. Tabalevich\n")
        f.write(f"ORCID: https://orcid.org/0009-0007-4425-9443\n\n")
        f.write(f"Dataset: {data_file}\n")
        f.write(f"Sample size: {len(df_valid)}\n\n")
        
        f.write("Correlations by interval type:\n")
        for interval_type, corr_data in correlations.items():
            f.write(f"\n{interval_type.upper()} interval:\n")
            for metric, value in corr_data.items():
                if value is not None:
                    f.write(f"  {metric}: {value:.6f}\n")
        
        f.write(f"\nSummary statistics:\n")
        f.write(f"  η range: [{df_valid['eta'].min()}, {df_valid['eta'].max()}]\n")
        f.write(f"  η mean: {df_valid['eta'].mean():.4f}\n")
    
    print(f"\n✓ Анализ завершен. Отчет сохранен в {report_file}")
    
    # Краткое резюме
    print("\n🔍 КРАТКОЕ РЕЗЮМЕ:")
    for interval_type, corr_data in correlations.items():
        primary_corr = corr_data.get('spearman') or corr_data.get('pearson')
        if primary_corr is not None:
            if primary_corr < -0.3:
                status = "✅ ПОДТВЕРЖДЕНА"
            elif primary_corr > 0.3:
                status = "❌ ОПРОВЕРГНУТА"
            else:
                status = "⚠️ НЕЯСНО"
            print(f"{interval_type}: корреляция = {primary_corr:.3f} → Гипотеза {status}")

if __name__ == "__main__":
    main()