# analyze_survival.py — Statistical Analysis of Survival Ratio vs η(k)
# Author: S. V. Tabalevich
# ORCID: https://orcid.org/0009-0007-4425-9443
# Analysis: Correlation between structural rank and prime survival in sieve

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
import sys

try:
    from scipy.stats import spearmanr, pearsonr, kendalltau
    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False
    print("⚠ scipy не установлен. Некоторые статистические тесты будут недоступны.")
    print("Установите: pip install scipy")

def load_data(filepath):
    """Загружает данные эксперимента."""
    try:
        df = pd.read_csv(filepath)
        print(f"✓ Загружено {len(df)} записей из {filepath}")
        return df
    except FileNotFoundError:
        print(f"❌ Файл {filepath} не найден.")
        print("Сначала запустите collect_data.py для сбора данных.")
        return None
    except Exception as e:
        print(f"❌ Ошибка при загрузке данных: {e}")
        return None

def filter_valid_data(df):
    """Фильтрует валидные данные для анализа."""
    initial_count = len(df)
    
    # Удаляем записи с ошибками
    df_clean = df[(df['eta'] > 0) & (df['survival_ratio'] >= 0) & (df['T_k'] > 0)]
    
    # Удаляем записи где η не найден (слишком большой)
    df_valid = df_clean[df_clean['eta'] <= 10000]  # Разумный верхний предел
    
    print(f"Исходных записей: {initial_count}")
    print(f"После очистки: {len(df_clean)}")
    print(f"Валидных для анализа: {len(df_valid)}")
    
    if len(df_valid) == 0:
        print("❌ Нет валидных данных для анализа!")
        return None
    
    return df_valid

def compute_correlations(df_valid):
    """Вычисляет различные коэффициенты корреляции."""
    eta_values = df_valid['eta'].values
    survival_values = df_valid['survival_ratio'].values
    
    correlations = {}
    
    # Корреляция Пирсона (линейная)
    try:
        pearson_corr = np.corrcoef(eta_values, survival_values)[0, 1]
        correlations['pearson'] = pearson_corr
    except:
        correlations['pearson'] = None
    
    if SCIPY_AVAILABLE:
        # Корреляция Спирмена (ранговая)
        try:
            spearman_corr, spearman_p = spearmanr(eta_values, survival_values)
            correlations['spearman'] = spearman_corr
            correlations['spearman_p'] = spearman_p
        except:
            correlations['spearman'] = None
            correlations['spearman_p'] = None
        
        # Тау Кендалла
        try:
            kendall_corr, kendall_p = kendalltau(eta_values, survival_values)
            correlations['kendall'] = kendall_corr
            correlations['kendall_p'] = kendall_p
        except:
            correlations['kendall'] = None
            correlations['kendall_p'] = None
    
    return correlations

def create_visualization(df_valid, output_dir='results'):
    """Создает визуализации корреляций."""
    Path(output_dir).mkdir(exist_ok=True)
    
    plt.style.use('default')
    
    # Основной scatter plot
    plt.figure(figsize=(12, 8))
    
    # Subplot 1: Основной график
    plt.subplot(2, 2, 1)
    plt.scatter(df_valid['eta'], df_valid['survival_ratio'], 
                alpha=0.6, s=20, c='blue', edgecolors='none')
    plt.xlabel('Структурный ранг η(k)')
    plt.ylabel('Коэффициент выживания в решете')
    plt.title('η(k) vs Survival Ratio')
    plt.grid(True, alpha=0.3)
    
    # Логарифмический масштаб для η
    if df_valid['eta'].max() > 100:
        plt.xscale('log')
    
    # Subplot 2: Гистограмма η
    plt.subplot(2, 2, 2)
    plt.hist(df_valid['eta'], bins=50, alpha=0.7, color='green', edgecolor='black')
    plt.xlabel('Структурный ранг η(k)')
    plt.ylabel('Частота')
    plt.title('Распределение η(k)')
    plt.grid(True, alpha=0.3)
    
    # Subplot 3: Гистограмма survival ratio
    plt.subplot(2, 2, 3)
    plt.hist(df_valid['survival_ratio'], bins=50, alpha=0.7, color='orange', edgecolor='black')
    plt.xlabel('Коэффициент выживания')
    plt.ylabel('Частота')
    plt.title('Распределение Survival Ratio')
    plt.grid(True, alpha=0.3)
    
    # Subplot 4: Boxplot по диапазонам η
    plt.subplot(2, 2, 4)
    
    # Разбиваем η на диапазоны для boxplot
    eta_bins = np.logspace(0, np.log10(df_valid['eta'].max()), 5) if df_valid['eta'].max() > 10 else [1, 2, 5, 10, df_valid['eta'].max()]
    df_valid['eta_bin'] = pd.cut(df_valid['eta'], bins=eta_bins, include_lowest=True)
    
    try:
        df_valid.boxplot(column='survival_ratio', by='eta_bin', ax=plt.gca())
        plt.xlabel('Диапазоны η(k)')
        plt.ylabel('Survival Ratio')
        plt.title('Survival Ratio по диапазонам η')
        plt.xticks(rotation=45)
        plt.suptitle('')  # Убираем автоматический заголовок
    except:
        plt.text(0.5, 0.5, 'Недостаточно данных\nдля boxplot', 
                ha='center', va='center', transform=plt.gca().transAxes)
    
    plt.tight_layout()
    plt.savefig(f"{output_dir}/survival_eta_analysis.png", dpi=150, bbox_inches='tight')
    plt.show()
    
    print(f"✓ Визуализация сохранена в {output_dir}/survival_eta_analysis.png")

def analyze_hypothesis(correlations, df_valid):
    """Анализирует гипотезу о связи η и survival ratio."""
    print("\n" + "="*60)
    print("АНАЛИЗ ГИПОТЕЗЫ: η(k) ↓ → Survival Ratio ↑")
    print("="*60)
    
    # Статистики
    print(f"Выборка: {len(df_valid)} точек")
    print(f"η(k) диапазон: [{df_valid['eta'].min()}, {df_valid['eta'].max()}]")
    print(f"Survival диапазон: [{df_valid['survival_ratio'].min():.4f}, {df_valid['survival_ratio'].max():.4f}]")
    print(f"Среднее η: {df_valid['eta'].mean():.2f}")
    print(f"Среднее survival: {df_valid['survival_ratio'].mean():.4f}")
    
    # Корреляции
    print(f"\n📊 КОРРЕЛЯЦИОННЫЙ АНАЛИЗ:")
    
    if correlations.get('pearson') is not None:
        print(f"Корреляция Пирсона: {correlations['pearson']:.4f}")
    
    if correlations.get('spearman') is not None:
        print(f"Корреляция Спирмена: {correlations['spearman']:.4f} (p = {correlations.get('spearman_p', 'N/A'):.2e})")
    
    if correlations.get('kendall') is not None:
        print(f"Тау Кендалла: {correlations['kendall']:.4f} (p = {correlations.get('kendall_p', 'N/A'):.2e})")
    
    # Интерпретация
    primary_corr = correlations.get('spearman') or correlations.get('pearson')
    
    if primary_corr is not None:
        print(f"\n🔍 ИНТЕРПРЕТАЦИЯ:")
        
        if primary_corr < -0.5:
            print("✅ СИЛЬНАЯ отрицательная корреляция!")
            print("   Гипотеза УБЕДИТЕЛЬНО подтверждается.")
        elif primary_corr < -0.3:
            print("✅ УМЕРЕННАЯ отрицательная корреляция.")
            print("   Гипотеза подтверждается.")
        elif primary_corr < -0.1:
            print("⚠️ СЛАБАЯ отрицательная корреляция.")
            print("   Некоторое подтверждение гипотезы.")
        elif primary_corr > 0.1:
            print("❌ ПОЛОЖИТЕЛЬНАЯ корреляция!")
            print("   Гипотеза НЕ подтверждается.")
        else:
            print("🤷 Корреляция практически отсутствует.")
            print("   Нейтральный результат.")
    
    # Проверка значимости
    if SCIPY_AVAILABLE and correlations.get('spearman_p') is not None:
        p_val = correlations['spearman_p']
        if p_val < 0.001:
            print(f"📈 Результат ВЫСОКО значим (p < 0.001)")
        elif p_val < 0.01:
            print(f"📈 Результат значим (p < 0.01)")
        elif p_val < 0.05:
            print(f"📈 Результат статистически значим (p < 0.05)")
        else:
            print(f"📉 Результат НЕ достигает статистической значимости (p = {p_val:.3f})")

def main():
    """Основная функция анализа."""
    print("Structural Rank η(k) vs Survival Ratio Analysis")
    print("Author: S. V. Tabalevich")
    print("===============================================")
    
    # Загружаем данные
    data_file = 'results/survival_eta_data.csv'
    df = load_data(data_file)
    if df is None:
        return
    
    # Фильтруем валидные данные
    df_valid = filter_valid_data(df)
    if df_valid is None:
        return
    
    # Вычисляем корреляции
    correlations = compute_correlations(df_valid)
    
    # Создаем визуализации
    create_visualization(df_valid)
    
    # Анализируем гипотезу
    analyze_hypothesis(correlations, df_valid)
    
    # Сохраняем результаты анализа
    results_file = 'results/survival_analysis_report.txt'
    with open(results_file, 'w', encoding='utf-8') as f:
        f.write("Survival Ratio vs η(k) Analysis Report\n")
        f.write("=====================================\n")
        f.write(f"Author: S. V. Tabalevich\n")
        f.write(f"Dataset: {data_file}\n")
        f.write(f"Sample size: {len(df_valid)}\n\n")
        
        f.write("Correlations:\n")
        for key, value in correlations.items():
            if value is not None:
                f.write(f"  {key}: {value:.6f}\n")
        
        f.write(f"\nSummary statistics:\n")
        f.write(f"  η range: [{df_valid['eta'].min()}, {df_valid['eta'].max()}]\n")
        f.write(f"  η mean: {df_valid['eta'].mean():.4f}\n")
        f.write(f"  survival range: [{df_valid['survival_ratio'].min():.6f}, {df_valid['survival_ratio'].max():.6f}]\n")
        f.write(f"  survival mean: {df_valid['survival_ratio'].mean():.6f}\n")
    
    print(f"\n✓ Анализ завершен. Отчет сохранен в {results_file}")

if __name__ == "__main__":
    main()