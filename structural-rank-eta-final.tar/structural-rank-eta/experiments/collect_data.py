# collect_data.py — Survival vs η experiment
# Author: S. V. Tabalevich
# ORCID: https://orcid.org/0009-0007-4425-9443
# Experiment: Correlation between structural rank η(k) and survival ratio in sieve

import os
import csv
import time
import subprocess
import sys
from pathlib import Path

def sieve_of_eratosthenes(limit):
    """Возвращает список простых до limit."""
    is_prime = [True] * (limit + 1)
    is_prime[0] = is_prime[1] = False
    for i in range(2, int(limit**0.5) + 1):
        if is_prime[i]:
            for j in range(i*i, limit + 1, i):
                is_prime[j] = False
    return [i for i, prime in enumerate(is_prime) if prime]

def compute_survival_ratio(T, k):
    """Вычисляет долю простых d < k, которые НЕ делят T."""
    primes = sieve_of_eratosthenes(k - 1)
    # Оставляем только нечётные d >= 3
    primes = [p for p in primes if p >= 3]
    if not primes:
        return 1.0
    non_divisors = sum(1 for d in primes if T % d != 0)
    return non_divisors / len(primes)

def get_eta_k_gpu(k, eta_max):
    """Получает η(k) используя CUDA анализатор."""
    # Вычисляем T(k) = |k - 2 + C(k)|, где C(k) = 1 + (-k mod 4)
    C = 1 + ((-k) % 4)
    T_k = abs(k - 2 + C)
    
    # Проверяем, что существует eta_scanner
    eta_scanner = Path("../eta_scanner/eta_congruent_gpu")
    if not eta_scanner.exists():
        print("❌ CUDA анализатор не найден. Запустите 'make' в ../eta_scanner/")
        return -1
    
    try:
        # Запускаем CUDA анализатор
        result = subprocess.run(
            [str(eta_scanner), str(T_k), str(eta_max)],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if result.returncode != 0:
            print(f"❌ Ошибка CUDA анализатора для k={k}: {result.stderr}")
            return -1
        
        # Парсим результат
        output = result.stdout
        if "✗ η =" in output:
            # Найден η
            for line in output.split('\n'):
                if "✗ η =" in line:
                    eta_val = int(line.split("η =")[1].split("FOUND!")[0].strip())
                    return eta_val
        else:
            # η не найден в заданном диапазоне
            return eta_max + 1
            
    except subprocess.TimeoutExpired:
        print(f"⏰ Таймаут для k={k}")
        return -1
    except Exception as e:
        print(f"❌ Ошибка для k={k}: {e}")
        return -1

def get_eta_k_fallback(k, eta_max):
    """Fallback реализация η(k) без CUDA."""
    C = 1 + ((-k) % 4)
    T_k = abs(k - 2 + C)
    
    if T_k % 4 != 3:
        return -1  # T должно быть ≡ 3 (mod 4)
    
    # Простая проверка для малых значений
    for n in range(1, min(eta_max + 1, 100)):
        two_n_minus_1 = 2 * n - 1
        candidate = T_k + two_n_minus_1 * two_n_minus_1
        
        # Проверяем, является ли candidate полным квадратом
        sqrt_candidate = int(candidate ** 0.5)
        if sqrt_candidate * sqrt_candidate == candidate:
            return n
    
    return eta_max + 1

def main():
    """Основная функция сбора данных."""
    print("Structural Rank η(k) vs Survival Ratio Experiment")
    print("Author: S. V. Tabalevich")
    print("================================================")
    
    # Создаем папку для результатов
    os.makedirs('results', exist_ok=True)
    output_file = 'results/survival_eta_data.csv'
    
    # Параметры эксперимента
    START_K = 10**5
    END_K = START_K + 1000  # Уменьшено для демонстрации
    ETA_MAX = 10**4
    
    print(f"Диапазон k: [{START_K}, {END_K}]")
    print(f"Максимальный поиск η: {ETA_MAX}")
    
    # Проверяем доступность CUDA анализатора
    use_gpu = Path("../eta_scanner/eta_congruent_gpu").exists()
    if use_gpu:
        print("✓ Используется CUDA анализатор")
    else:
        print("⚠ CUDA анализатор недоступен, используется fallback")
    
    start_time = time.time()
    processed = 0
    found_eta = 0
    
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['k', 'T_k', 'eta', 'survival_ratio', 'computation_method'])

        for k in range(START_K, END_K + 1):
            try:
                # T(k) = k - 2 + C(k), C(k) = 1 + (-k mod 4)
                C = 1 + ((-k) % 4)
                T_k = k - 2 + C  # Лемма А1 гарантирует неотрицательность
                
                # Получаем η(k)
                if use_gpu:
                    eta_val = get_eta_k_gpu(k, ETA_MAX)
                else:
                    eta_val = get_eta_k_fallback(k, ETA_MAX)
                
                # Вычисляем survival ratio
                survival_ratio = compute_survival_ratio(T_k, k)
                
                method = "CUDA" if use_gpu else "CPU_fallback"
                writer.writerow([k, T_k, eta_val, survival_ratio, method])
                
                processed += 1
                if eta_val > 0 and eta_val <= ETA_MAX:
                    found_eta += 1
                
                # Прогресс
                if processed % 100 == 0:
                    elapsed = time.time() - start_time
                    rate = processed / elapsed
                    eta_rate = found_eta / processed * 100
                    print(f"Обработано: {processed}, η найден: {found_eta} ({eta_rate:.1f}%), скорость: {rate:.1f} k/сек")
                    
            except Exception as e:
                print(f"❌ Ошибка при k={k}: {e}")
                writer.writerow([k, T_k, -1, -1, "ERROR"])

    elapsed_time = time.time() - start_time
    print(f"\n✓ Эксперимент завершен!")
    print(f"Время выполнения: {elapsed_time:.1f} сек")
    print(f"Обработано значений k: {processed}")
    print(f"Найдено η-значений: {found_eta}")
    print(f"Результаты сохранены в: {output_file}")
    
    # Быстрый анализ
    if found_eta > 10:
        print(f"\n📊 Быстрый анализ:")
        print(f"Доля найденных η: {found_eta/processed*100:.1f}%")
        
        # Считываем данные для анализа
        try:
            import pandas as pd
            df = pd.read_csv(output_file)
            valid_df = df[(df['eta'] > 0) & (df['eta'] <= ETA_MAX)]
            
            if len(valid_df) > 5:
                print(f"Среднее η: {valid_df['eta'].mean():.2f}")
                print(f"Медиана η: {valid_df['eta'].median():.2f}")
                print(f"Среднее survival ratio: {valid_df['survival_ratio'].mean():.4f}")
                
                # Корреляция
                correlation = valid_df['eta'].corr(valid_df['survival_ratio'])
                print(f"Корреляция η vs survival: {correlation:.4f}")
                
                if correlation < -0.2:
                    print("✓ Обнаружена отрицательная корреляция (η↓ → survival↑)")
                else:
                    print("⚠ Корреляция слабая или отсутствует")
        except ImportError:
            print("📊 Для подробного анализа установите pandas: pip install pandas")

if __name__ == "__main__":
    main()